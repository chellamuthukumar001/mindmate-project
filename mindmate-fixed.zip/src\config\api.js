// API Configuration
export const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

export const API_ENDPOINTS = {
    chat: `${API_URL}/chat`,
    health: `${API_URL}/health`,
    moods: `${API_URL}/api/moods`,
    journals: `${API_URL}/api/journals`,
};
