# 🚀 Quick Fix: Connect Your Backend to Vercel

Your MindMate-project is deployed on Vercel, but the backend isn't connected yet. Here's how to fix it in **5 minutes**:

---

## ✅ **Step 1: Deploy Backend to Render (FREE)**

1. **Go to Render**: https://render.com
2. **Sign up/Login** with your GitHub account
3. **Click "New +" → "Web Service"**
4. **Connect** your `Mindmate-project` repository from GitHub
5. **Configure**:
   ```
   Name: mindmate-backend
   Environment: Node
   Build Command: npm install  
   Start Command: npm start
   ```
6. **Add Environment Variable**:
   - Click "Environment" tab
   - Add: **`GROQ_API_KEY`** = `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`

7. **Click "Create Web Service"** and wait 2-3 minutes

8. **Copy your backend URL** - it will look like:
   ```
   https://mindmate-backend-xxxx.onrender.com
   ```

---

## ✅ **Step 2: Connect Backend to Your Vercel Deploy**

1. **Go to Vercel Dashboard**: https://vercel.com/dashboard
2. Find **"Mindmate-project"** (or your project name)
3. Click **Settings → Environment Variables**
4. **Add New Variable**:
   ```
   Name: VITE_API_URL
   Value: https://mindmate-backend-xxxx.onrender.com
   ```
   (Replace with YOUR actual Render URL from Step 1)

5. **Save**

---

## ✅ **Step 3: Redeploy Frontend**

1. Stay in your Vercel Dashboard
2. Go to **Deployments** tab
3. Click **"..."** on the latest deployment
4. Click **"Redeploy"**
5. Wait 30-60 seconds

---

## 🎉 **Done! Test It**

1. Visit your Vercel URL (e.g., `https://mindmate-project.vercel.app`)
2. Click **"Chat with MindMate"** 
3. Send a message - it should work! ✨

---

## 🔍 **Troubleshooting**

### Backend taking too long to respond?
- **Render free tier "sleeps"** after 15 min of inactivity
- First request after sleep takes **30-60 seconds**
- Visit `https://your-backend.onrender.com/health` to wake it up

### Still see errors?
- Open browser console (F12)
- Check if environment variable was set correctly in Vercel
- Make sure you **redeployed** after adding the env var

### CORS errors?
- Already fixed! The backend has CORS enabled for all origins

---

## 📋 **What Was Fixed**

✅ Backend now uses `process.env.PORT` for cloud deployment  
✅ Frontend uses `VITE_API_URL` environment variable  
✅ ChatPage and MoodPage use centralized API config  
✅ All API URLs are configurable via environment variables  

---

**Need help?** Let me know!
