# 🚀 MindMate Deployment Guide

This guide will help you deploy your MindMate app with a working backend.

## 🎯 Architecture

MindMate requires **two separate deployments**:
1. **Frontend** (React app) → Vercel/Netlify
2. **Backend** (Express server) → Render/Railway/Heroku

## 📦 **Step 1: Deploy Backend (Render - FREE)**

### Option A: Using Render (Recommended - Free Tier)

1. **Go to Render**: https://render.com
2. **Sign up/Login** with GitHub
3. **Click "New +" → "Web Service"**
4. **Connect your GitHub repository**: `Mindmate`
5. **Configure the service**:
   - **Name**: `mindmate-backend`
   - **Environment**: `Node`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Instance Type**: `Free`

6. **Add Environment Variables**:
   - Click "Environment" tab
   - Add variable:
     - **Key**: `GROQ_API_KEY`
     - **Value**: `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`

7. **Click "Create Web Service"**

8. **Wait 2-3 minutes** for deployment

9. **Copy your backend URL**: It will look like:
   ```
   https://mindmate-backend-xxxx.onrender.com
   ```

### Option B: Using Railway (Alternative - Free Tier)

1. **Go to Railway**: https://railway.app
2. **Sign up with GitHub**
3. **Click "New Project" → "Deploy from GitHub repo"**
4. **Select `Mindmate` repository**
5. **Add Environment Variables**:
   - `GROQ_API_KEY` = `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`
6. **Deploy**
7. **Copy your Railway URL** from Settings → Domains

---

## 🌐 **Step 2: Deploy Frontend (Vercel - FREE)**

### If you deployed to Vercel already:

1. **Go to your Vercel dashboard**: https://vercel.com/dashboard
2. **Find your MindMate project**
3. **Go to Settings → Environment Variables**
4. **Add this variable**:
   - **Name**: `VITE_API_URL`
   - **Value**: `https://mindmate-backend-xxxx.onrender.com` (your backend URL from Step 1)
5. **Click "Add"**
6. **Go to Deployments tab**
7. **Click "..." on the latest deployment → "Redeploy"**

### If you haven't deployed frontend yet:

1. **Go to Vercel**: https://vercel.com
2. **Sign up/Login with GitHub**
3. **Click "Add New..." → "Project"**
4. **Import your `Mindmate` repository**
5. **Configure**:
   - **Framework Preset**: Vite
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
6. **Add Environment Variable**:
   - **Name**: `VITE_API_URL`
   - **Value**: `https://mindmate-backend-xxxx.onrender.com`
7. **Click "Deploy"**

---

## ✅ **Step 3: Test Your Deployment**

1. **Visit your Vercel URL** (e.g., `https://mindmate-xxx.vercel.app`)
2. **Click "Chat with MindMate"**
3. **Send a message** - it should work!

If chat doesn't work:
- Check backend is running: Visit `https://your-backend-url.onrender.com/health`
- Check browser console for errors (F12)

---

## 🔧 **Troubleshooting**

### Backend not responding?
- **Free tier sleep**: Render free tier goes to sleep after 15 minutes of inactivity
- **First request might take 30-60 seconds** to wake up the server
- Visit `/health` endpoint to wake it up

### CORS errors?
The backend is already configured with CORS. If you still see errors:
1. Go to `server.js`
2. Update CORS to allow your Vercel domain:
```javascript
app.use(cors({
  origin: ['https://your-app.vercel.app', 'http://localhost:5173']
}));
```

### Environment variables not working?
- Make sure you added `VITE_API_URL` to **Vercel**
- Make sure you added `GROQ_API_KEY` to **Render/Railway**
- Redeploy after adding environment variables

---

## 📊 **Free Tier Limits**

### Render (Backend)
- ✅ 750 hours/month free
- ✅ Sleeps after 15 min inactivity
- ✅ Unlimited deploys

### Vercel (Frontend)
- ✅ Unlimited bandwidth
- ✅ 100 GB bandwidth/month
- ✅ Always online

---

## 🎉 **You're Done!**

Your MindMate app is now **fully deployed and accessible worldwide**!

**Frontend**: `https://your-mindmate.vercel.app`  
**Backend**: `https://mindmate-backend.onrender.com`

Share the frontend URL with anyone! 🌍

---

## 📝 **Quick Reference**

### Update Code:
1. Push to GitHub
2. Vercel & Render auto-deploy (if connected)

### View Logs:
- **Vercel**: Dashboard → Your Project → Deployments → View Logs
- **Render**: Dashboard → mindmate-backend → Logs

### Change Backend URL:
1. Update `VITE_API_URL` in Vercel environment variables
2. Redeploy frontend
